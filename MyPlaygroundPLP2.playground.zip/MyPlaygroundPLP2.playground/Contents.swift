import UIKit

// int
var integerVal: Int = 10

// string
var stringVal: String = "PLP2"

// floating-point number
var floatVal: Float = 3.14

// double
var doubleVal: Double = 3.14159

// boolean
var booleanVal: Bool = true

// array
var arrayVal: [Int] = [1, 2, 3, 4, 5]

// dictionary
var dictionaryVal: [String: Any] = ["Name": "Karley", "Age": 20, "simmonsStudent": true]
